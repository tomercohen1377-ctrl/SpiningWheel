/**
 * react-native-spinwheel
 *
 * Public entry point.
 *
 * Usage:
 * ```ts
 * import SpinWheelModule from 'react-native-spinwheel';
 *
 * // Sync assets and update the home-screen widget
 * await SpinWheelModule.syncWidgetConfiguration('https://…/config.json');
 *
 * // Get timestamp of last sync
 * const ts: number = await SpinWheelModule.getLastFetchTime();
 * ```
 */
import type { ISpinWheelModule } from './types';
declare const _default: ISpinWheelModule;
export default _default;
export type { ISpinWheelModule };
//# sourceMappingURL=index.d.ts.map