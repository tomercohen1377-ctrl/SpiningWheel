package com.example.spinwheel.ui

import android.content.Context
import android.util.Log
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.state.updateAppWidgetState
import com.example.spinwheel.di.SpinWheelGraph
import kotlinx.coroutines.runBlocking

/**
 * Glance [ActionCallback] invoked when the user taps "Tap to load" / "Tap
 * to retry" on the widget.
 *
 * The bridge (`SpinWheelModule.syncWidgetConfiguration`) is the *primary*
 * downloader. This callback exists so the widget is functional when launched
 * before any sync has happened (e.g. user adds the widget directly,
 * without ever opening the RN app).
 *
 * Behaviour:
 * - If all 4 image bytes are on disk already → just refresh the widget so
 *   the latest state is rendered. We do NOT re-download.
 * - If `config_url` is set but images are missing → show an error pointing
 *   at the RN app, so the user knows to retry the sync.
 * - If no URL and no images → "No config URL cached" error.
 */
class LoadWheelActionCallback : ActionCallback {

    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters,
    ) {
        showLoading(context, glanceId)
        checkOrError(context, glanceId)
    }

    private suspend fun checkOrError(context: Context, glanceId: GlanceId) {
        val graph = SpinWheelGraph.get(context)
        val (hasAllImages, hasUrl) = runBlocking {
            graph.local.hasAllImages() to (graph.local.getConfigUrl() != null)
        }

        if (!hasUrl) {
            showError(
                context,
                glanceId,
                "No config URL cached yet.\nOpen the RN app and tap 'Sync Widget Assets' first.",
            )
            return
        }
        if (!hasAllImages) {
            showError(
                context,
                glanceId,
                "Cached URL is set but images are missing.\nRe-open the RN app and tap 'Sync Widget Assets'.",
            )
            return
        }

        // All good — just refresh the widget with whatever's on disk.
        clearErrorState(context, glanceId)
        SpinWheelGlanceWidget().update(context, glanceId)
    }

    private suspend fun showLoading(context: Context, glanceId: GlanceId) {
        updateAppWidgetState(context, glanceId) { prefs ->
            prefs[SpinWheelGlanceWidget.IS_LOADING_KEY] = true
            prefs.remove(SpinWheelGlanceWidget.ERROR_MESSAGE_KEY)
        }
        SpinWheelGlanceWidget().update(context, glanceId)
    }

    private suspend fun clearErrorState(context: Context, glanceId: GlanceId) {
        updateAppWidgetState(context, glanceId) {prefs ->
            prefs[SpinWheelGlanceWidget.IS_LOADING_KEY] = false
            prefs.remove(SpinWheelGlanceWidget.ERROR_MESSAGE_KEY)
        }
    }

    private suspend fun showError(context: Context, glanceId: GlanceId, message: String) {
        Log.e(TAG, "Load failed: $message")
        updateAppWidgetState(context, glanceId) {prefs ->
            prefs[SpinWheelGlanceWidget.IS_LOADING_KEY] = false
            prefs[SpinWheelGlanceWidget.ERROR_MESSAGE_KEY] = message
        }
        SpinWheelGlanceWidget().update(context, glanceId)
    }

    private companion object {
        const val TAG = "LoadWheelCallback"
    }
}
